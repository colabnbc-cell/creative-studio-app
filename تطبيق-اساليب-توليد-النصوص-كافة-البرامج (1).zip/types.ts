
export type Theme = 'light' | 'dark';

export enum VIEW {
    DASHBOARD = 'لوحة التحكم',
    PROGRAM_MANAGEMENT = 'إدارة البرامج',
    SCRIPT_LIBRARY = 'مكتبة النصوص',
    NEW_SCRIPT = 'نص جديد',
    EPISODE_IDEAS = 'أفكار حلقات',
    DEEP_RESEARCH = 'بحث معمق',
    FACT_CHECK = 'تدقيق الحقائق',
    SETTINGS = 'الإعدادات',
    PROGRAM_DETAILS = 'تفاصيل البرنامج',
}

export interface Program {
    id: string;
    name: string;
    genre: string;
    targetAudience: string;
    episodeLength: string;
    styleReferences: string[];
}

export interface ApiKeys {
    claude: string;
    chatgpt: string;
    other: string;
}

export interface Source {
    uri: string;
    title: string;
}

export interface GeneratedScript {
    title: string;
    content: string;
    programName: string;
    date: string;
    sources: Source[];
}

export enum Mode {
    SINGLE = 'نموذج واحد',
    HYBRID = 'هجين (Gemini + المختار)',
    CROSS_CHECK = 'تحقق متقاطع (كل النماذج)',
}

export enum Model {
    GEMINI = 'Gemini',
    CLAUDE = 'Claude',
    CHATGPT = 'ChatGPT',
    OTHER = 'Other',
}

export interface Message {
  sender: 'user' | 'bot';
  text: string;
  isLoading?: boolean;
}
