import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { ProgramManagement } from './components/ProgramManagement';
import { NewScript } from './components/NewScript';
import { Settings } from './components/Settings';
import { EpisodeIdeas } from './components/EpisodeIdeas';
import { DeepResearch } from './components/DeepResearch';
import { FactCheck } from './components/FactCheck';
import { ScriptLibrary } from './components/ScriptLibrary';
import { ProgramDetails } from './components/ProgramDetails';
import type { Theme, Program, ApiKeys, GeneratedScript } from './types';
import { VIEW } from './types';
import { INITIAL_PROGRAMS } from './constants';

// localStorage Keys
const LOCAL_STORAGE_KEYS = {
    PROGRAMS: 'discoveryApp_programs',
    SAVED_SCRIPTS: 'discoveryApp_savedScripts',
    FACT_CHECK_COUNT: 'discoveryApp_factCheckCount',
    IDEAS_GENERATED_COUNT: 'discoveryApp_ideasGeneratedCount',
    API_KEYS: 'discoveryApp_apiKeys',
};

const App: React.FC = () => {
  const [theme, setTheme] = useState<Theme>('dark');
  const [view, setView] = useState<VIEW>(VIEW.DASHBOARD);
  const [selectedProgram, setSelectedProgram] = useState<Program | null>(null);

  // Load state from localStorage on initial render
  const [programs, setPrograms] = useState<Program[]>(() => {
    try {
        const item = window.localStorage.getItem(LOCAL_STORAGE_KEYS.PROGRAMS);
        // If programs exist in storage, use them, otherwise seed with initial data
        return item ? JSON.parse(item) : INITIAL_PROGRAMS;
    } catch (error) {
        console.warn('Error reading programs from localStorage', error);
        return INITIAL_PROGRAMS;
    }
  });

  const [apiKeys, setApiKeys] = useState<ApiKeys>(() => {
    try {
        const item = window.localStorage.getItem(LOCAL_STORAGE_KEYS.API_KEYS);
        return item ? JSON.parse(item) : { claude: '', chatgpt: '', other: '' };
    } catch (error) {
        console.warn('Error reading apiKeys from localStorage', error);
        return { claude: '', chatgpt: '', other: '' };
    }
  });
  
  const [savedScripts, setSavedScripts] = useState<GeneratedScript[]>(() => {
    try {
        const item = window.localStorage.getItem(LOCAL_STORAGE_KEYS.SAVED_SCRIPTS);
        return item ? JSON.parse(item) : [];
    } catch (error) {
        console.warn('Error reading savedScripts from localStorage', error);
        return [];
    }
  });

  const [factCheckCount, setFactCheckCount] = useState<number>(() => {
     try {
        const item = window.localStorage.getItem(LOCAL_STORAGE_KEYS.FACT_CHECK_COUNT);
        return parseInt(item || '0', 10);
    } catch (error) {
        console.warn('Error reading factCheckCount from localStorage', error);
        return 0;
    }
  });

  const [ideasGeneratedCount, setIdeasGeneratedCount] = useState<number>(() => {
    try {
        const item = window.localStorage.getItem(LOCAL_STORAGE_KEYS.IDEAS_GENERATED_COUNT);
        return parseInt(item || '0', 10);
    } catch (error) {
        console.warn('Error reading ideasGeneratedCount from localStorage', error);
        return 0;
    }
  });

  // Save state to localStorage whenever it changes
   useEffect(() => {
    try {
        window.localStorage.setItem(LOCAL_STORAGE_KEYS.PROGRAMS, JSON.stringify(programs));
    } catch (error) {
        console.error('Error saving programs to localStorage', error);
    }
  }, [programs]);

  useEffect(() => {
    try {
        window.localStorage.setItem(LOCAL_STORAGE_KEYS.API_KEYS, JSON.stringify(apiKeys));
    } catch (error) {
        console.error('Error saving api keys to localStorage', error);
    }
  }, [apiKeys]);

  useEffect(() => {
    try {
        window.localStorage.setItem(LOCAL_STORAGE_KEYS.SAVED_SCRIPTS, JSON.stringify(savedScripts));
    } catch (error) {
        console.error('Error saving scripts to localStorage', error);
    }
  }, [savedScripts]);

  useEffect(() => {
    try {
        window.localStorage.setItem(LOCAL_STORAGE_KEYS.FACT_CHECK_COUNT, String(factCheckCount));
    } catch (error) {
        console.error('Error saving fact check count to localStorage', error);
    }
  }, [factCheckCount]);

  useEffect(() => {
    try {
        window.localStorage.setItem(LOCAL_STORAGE_KEYS.IDEAS_GENERATED_COUNT, String(ideasGeneratedCount));
    } catch (error) {
        console.error('Error saving ideas count to localStorage', error);
    }
  }, [ideasGeneratedCount]);

  const addScriptToLibrary = (script: GeneratedScript) => {
    setSavedScripts(prev => [script, ...prev]);
  };

  const addProgram = (newProgramData: Omit<Program, 'id'>) => {
    const newProgram: Program = {
        ...newProgramData,
        id: `program-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };
    setPrograms(prev => [newProgram, ...prev]);
  };

  const updateProgram = (updatedProgram: Program) => {
    setPrograms(prevPrograms => 
        prevPrograms.map(p => p.id === updatedProgram.id ? updatedProgram : p)
    );
  };

  const handleFactCheckSuccess = () => {
    setFactCheckCount(prev => prev + 1);
  };

  const handleIdeasGeneratedSuccess = () => {
    setIdeasGeneratedCount(prev => prev + 1);
  };


  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove(theme === 'light' ? 'dark' : 'light');
    root.classList.add(theme);
  }, [theme]);

  const renderView = () => {
    switch (view) {
      case VIEW.DASHBOARD:
        return <Dashboard scripts={savedScripts} factCheckCount={factCheckCount} ideasGeneratedCount={ideasGeneratedCount} />;
      case VIEW.PROGRAM_MANAGEMENT:
        return <ProgramManagement programs={programs} setView={setView} setSelectedProgram={setSelectedProgram} addProgram={addProgram} updateProgram={updateProgram} />;
      case VIEW.PROGRAM_DETAILS:
        if (selectedProgram) {
            return <ProgramDetails program={selectedProgram} apiKeys={apiKeys} addScriptToLibrary={addScriptToLibrary} updateProgram={updateProgram} />;
        }
        // Fallback to management if no program is selected
        setView(VIEW.PROGRAM_MANAGEMENT);
        return <ProgramManagement programs={programs} setView={setView} setSelectedProgram={setSelectedProgram} addProgram={addProgram} updateProgram={updateProgram} />;
      case VIEW.NEW_SCRIPT:
        return <NewScript apiKeys={apiKeys} addScriptToLibrary={addScriptToLibrary} programs={programs} />;
      case VIEW.EPISODE_IDEAS:
        return <EpisodeIdeas programs={programs} onIdeasGenerated={handleIdeasGeneratedSuccess} apiKeys={apiKeys} />;
      case VIEW.DEEP_RESEARCH:
        return <DeepResearch apiKeys={apiKeys} />;
      case VIEW.FACT_CHECK:
        return <FactCheck apiKeys={apiKeys} onFactCheck={handleFactCheckSuccess} />;
      case VIEW.SCRIPT_LIBRARY:
        return <ScriptLibrary scripts={savedScripts} />;
       case VIEW.SETTINGS:
        return <Settings apiKeys={apiKeys} setApiKeys={setApiKeys} />;
      default:
        return <Dashboard scripts={savedScripts} factCheckCount={factCheckCount} ideasGeneratedCount={ideasGeneratedCount} />;
    }
  };

  return (
    <div className="bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100 min-h-screen font-sans">
      <div className="flex">
        <Sidebar currentView={view} setView={setView} />
        <main className="flex-1 transition-all duration-300">
          <Header theme={theme} setTheme={setTheme} currentView={view} currentProgram={selectedProgram} />
          <div className="p-4 md:p-8">
            {renderView()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;