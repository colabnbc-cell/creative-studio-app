
import React from 'react';
import type { ApiKeys } from '../types';

interface SettingsProps {
    apiKeys: ApiKeys;
    setApiKeys: (keys: ApiKeys) => void;
}

const ApiKeyInput: React.FC<{ 
    label: string;
    id: keyof ApiKeys | 'gemini'; 
    value: string;
    placeholder: string;
    disabled?: boolean;
    helpText?: string;
    onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}> = ({ label, id, value, placeholder, disabled = false, helpText, onChange }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{label}</label>
        <input 
            type="password" 
            id={id} 
            name={id}
            value={value} 
            onChange={onChange}
            placeholder={placeholder}
            disabled={disabled}
            className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 disabled:bg-gray-100 dark:disabled:bg-gray-700/50"
        />
        {helpText && <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">{helpText}</p>}
    </div>
);


export const Settings: React.FC<SettingsProps> = ({ apiKeys, setApiKeys }) => {

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setApiKeys({
            ...apiKeys,
            [name]: value,
        });
    };

    return (
        <div className="max-w-2xl mx-auto">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md">
                 <h2 className="text-2xl font-bold mb-2">إدارة مفاتيح API</h2>
                 <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">
                    أدخل مفاتيح API الخاصة بك هنا لتفعيل النماذج المختلفة. سيتم حفظ المفاتيح بشكل آمن.
                 </p>
                 <div className="space-y-6">
                     <ApiKeyInput 
                        label="مفتاح Gemini API"
                        id="gemini"
                        value="********************"
                        placeholder=""
                        disabled={true}
                        helpText="يتم تحميل مفتاح Gemini API تلقائيًا من متغيرات البيئة (process.env.API_KEY) وهو متصل."
                     />
                     <ApiKeyInput 
                        label="مفتاح Claude API"
                        id="claude"
                        value={apiKeys.claude}
                        onChange={handleChange}
                        placeholder="أدخل مفتاح Claude API هنا"
                     />
                      <ApiKeyInput 
                        label="مفتاح ChatGPT API"
                        id="chatgpt"
                        value={apiKeys.chatgpt}
                        onChange={handleChange}
                        placeholder="أدخل مفتاح ChatGPT API هنا"
                     />
                      <ApiKeyInput 
                        label="مفتاح API لنموذج آخر"
                        id="other"
                        value={apiKeys.other}
                        onChange={handleChange}
                        placeholder="أدخل مفتاح API لنموذج آخر"
                     />
                 </div>
            </div>
        </div>
    );
};