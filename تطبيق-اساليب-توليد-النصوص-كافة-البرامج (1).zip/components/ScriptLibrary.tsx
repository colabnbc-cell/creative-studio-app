import React, { useState } from 'react';
import type { GeneratedScript } from '../types';
import { renderWithLinks } from './utils';

interface ScriptLibraryProps {
    scripts: GeneratedScript[];
}

const ScriptViewerModal: React.FC<{ script: GeneratedScript; onClose: () => void }> = ({ script, onClose }) => {
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50" onClick={onClose}>
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl p-6 md:p-8 w-11/12 md:w-3/4 lg:w-2/3 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-4">
                    <div>
                        <h2 className="text-2xl font-bold text-blue-500">{script.title}</h2>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{script.programName} - {script.date}</p>
                    </div>
                    <button onClick={onClose} className="text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-white text-3xl font-bold">&times;</button>
                </div>
                <div className="prose prose-sm sm:prose dark:prose-invert max-w-none whitespace-pre-wrap leading-relaxed">
                    {renderWithLinks(script.content)}
                </div>
                {script.sources.length > 0 && (
                    <div className="mt-8 pt-4 border-t border-gray-200 dark:border-gray-700">
                        <h4 className="text-lg font-semibold mb-2">المصادر والمراجع الإضافية</h4>
                        <ul className="list-disc pr-5 space-y-1">
                            {script.sources.map((source, index) => (
                                <li key={index} className="text-sm">
                                    <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">
                                        {source.title || source.uri}
                                    </a>
                                </li>
                            ))}
                        </ul>
                    </div>
                )}
            </div>
        </div>
    );
};

export const ScriptLibrary: React.FC<ScriptLibraryProps> = ({ scripts }) => {
    const [selectedScript, setSelectedScript] = useState<GeneratedScript | null>(null);

    return (
        <>
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md">
                <h2 className="text-2xl font-bold mb-6">مكتبة النصوص</h2>
                {scripts.length === 0 ? (
                    <div className="text-center py-20 text-gray-500 dark:text-gray-400">
                        <p className="text-3xl mb-2">📚</p>
                        <p>المكتبة فارغة حاليًا.</p>
                        <p className="text-sm">سيتم عرض النصوص التي تقوم بإنشائها هنا تلقائيًا.</p>
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-right text-gray-500 dark:text-gray-400">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                <tr>
                                    <th scope="col" className="px-6 py-3">عنوان الحلقة</th>
                                    <th scope="col" className="px-6 py-3">البرنامج</th>
                                    <th scope="col" className="px-6 py-3">تاريخ الإنشاء</th>
                                    <th scope="col" className="px-6 py-3">الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                {scripts.map((script, index) => (
                                    <tr key={index} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                        <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                            {script.title}
                                        </th>
                                        <td className="px-6 py-4">{script.programName}</td>
                                        <td className="px-6 py-4">{script.date}</td>
                                        <td className="px-6 py-4">
                                            <button onClick={() => setSelectedScript(script)} className="font-medium text-blue-600 dark:text-blue-500 hover:underline">عرض</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
            {selectedScript && <ScriptViewerModal script={selectedScript} onClose={() => setSelectedScript(null)} />}
        </>
    );
};