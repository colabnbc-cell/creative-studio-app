import React, { useState, useEffect } from 'react';
import { performDeepResearch } from '../services/geminiService';
import type { Source, ApiKeys } from '../types';
import { Mode, Model } from '../types';
import { renderWithLinks } from './utils';

interface DeepResearchProps {
    apiKeys: ApiKeys;
}

const researchSteps = [
  'تحليل الموضوع الرئيسي',
  'البحث في المصادر الأكاديمية',
  'تجميع البيانات من الشبكة العميقة',
  'التحقق المتقاطع من الحقائق',
  'صياغة التقرير النهائي'
];

export const DeepResearch: React.FC<DeepResearchProps> = ({ apiKeys }) => {
    const [topic, setTopic] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [researchResult, setResearchResult] = useState<string>('');
    const [sources, setSources] = useState<Source[]>([]);
    const [error, setError] = useState<string>('');
    const [selectedMode, setSelectedMode] = useState<Mode>(Mode.SINGLE);
    const [selectedModel, setSelectedModel] = useState<Model>(Model.GEMINI);
    const [currentStep, setCurrentStep] = useState<number>(0);

    useEffect(() => {
        let interval: number | undefined;
        if (isLoading) {
          setCurrentStep(0); // Start from the first step
          interval = window.setInterval(() => {
            setCurrentStep(prevStep => {
              if (prevStep < researchSteps.length - 1) {
                return prevStep + 1;
              }
              return prevStep; // Stay at the last step
            });
          }, 1500); 
        }
    
        return () => {
          if (interval) {
            clearInterval(interval);
          }
        };
    }, [isLoading]);

    const handleResearch = async () => {
        if (!topic.trim()) {
            setError('يرجى إدخال موضوع للبحث.');
            return;
        }
        setError('');
        setIsLoading(true);
        setResearchResult('');
        setSources([]);

        try {
            const result = await performDeepResearch(topic, selectedMode, selectedModel, apiKeys);
            setResearchResult(result.research);
            setSources(result.sources);
        } catch (err: any) {
            setError(err.message || 'حدث خطأ غير متوقع.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const modelOptions: { value: Model, label: string, disabled: boolean }[] = [
      { value: Model.GEMINI, label: Model.GEMINI, disabled: false },
      { value: Model.CLAUDE, label: Model.CLAUDE, disabled: !apiKeys.claude },
      { value: Model.CHATGPT, label: Model.CHATGPT, disabled: !apiKeys.chatgpt },
      { value: Model.OTHER, label: Model.OTHER, disabled: !apiKeys.other },
    ];

    return (
        <div className="max-w-4xl mx-auto">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md mb-6">
                <h3 className="text-xl font-bold mb-4">البحث المعمق</h3>
                <div className="space-y-4">
                     <div>
                        <label htmlFor="research-topic" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">أدخل موضوع البحث</label>
                        <input type="text" id="research-topic" value={topic} onChange={e => setTopic(e.target.value)} placeholder="مثال: تاريخ استكشاف المريخ" className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500" />
                    </div>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                         <div>
                            <label htmlFor="model-research" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اختر نموذج البحث</label>
                            <select 
                                id="model-research" 
                                value={selectedModel} 
                                onChange={e => setSelectedModel(e.target.value as Model)} 
                                className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500"
                            >
                              {modelOptions.map(opt => <option key={opt.value} value={opt.value} disabled={opt.disabled}>{opt.label}{opt.disabled ? ' (مفتاح غير مضاف)' : ''}</option>)}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="mode-research" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اختر وضع البحث</label>
                            <select 
                                id="mode-research" 
                                value={selectedMode} 
                                onChange={e => setSelectedMode(e.target.value as Mode)} 
                                className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500"
                            >
                               {Object.values(Mode).map(mode => <option key={mode} value={mode}>{mode}</option>)}
                            </select>
                        </div>
                    </div>
                    <button onClick={handleResearch} disabled={isLoading} className="w-full flex justify-center items-center py-2 px-6 border border-transparent rounded-md shadow-sm text-md font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed whitespace-nowrap">
                         {isLoading ? 'جاري البحث...' : '🌍 ابدأ البحث'}
                    </button>
                </div>
                {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 min-h-[400px]">
                <h3 className="text-2xl font-bold mb-4">نتائج البحث</h3>
                {isLoading && (
                    <div className="flex flex-col items-center justify-center h-full">
                        <div className="space-y-4 p-4 max-w-sm w-full">
                            <h4 className="text-lg font-semibold text-center text-gray-700 dark:text-gray-300">جاري إجراء البحث...</h4>
                            <div className="space-y-3">
                                {researchSteps.map((step, index) => (
                                    <div key={index} className={`flex items-center space-x-3 space-x-reverse text-sm transition-opacity duration-500 ${index <= currentStep ? 'opacity-100' : 'opacity-50'}`}>
                                        {index < currentStep ? (
                                            <svg className="w-5 h-5 text-green-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path></svg>
                                        ) : index === currentStep ? (
                                            <svg className="w-5 h-5 text-blue-500 animate-spin flex-shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                            </svg>
                                        ) : (
                                            <svg className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd"></path></svg>
                                        )}
                                        <span className={`${index <= currentStep ? 'text-gray-800 dark:text-gray-200 font-medium' : 'text-gray-500 dark:text-gray-400'}`}>
                                            {step}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}
                {!isLoading && !researchResult && (
                    <div className="text-center py-10 text-gray-500 dark:text-gray-400">
                        <p>ستظهر نتائج البحث المعمق هنا.</p>
                    </div>
                )}
                {researchResult && (
                    <div className="prose prose-sm sm:prose dark:prose-invert max-w-none whitespace-pre-wrap leading-relaxed">
                        {renderWithLinks(researchResult)}
                    </div>
                )}
                {sources.length > 0 && (
                    <div className="mt-8 pt-4 border-t border-gray-200 dark:border-gray-700">
                        <h4 className="text-lg font-semibold mb-2">المصادر الإضافية</h4>
                        <ul className="list-disc pr-5 space-y-1">
                            {sources.map((source, index) => (
                                <li key={index} className="text-sm">
                                    <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">
                                        {source.title || source.uri}
                                    </a>
                                </li>
                            ))}
                        </ul>
                    </div>
                )}
            </div>
        </div>
    );
};
