import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import type { GeneratedScript } from '../types';

interface DashboardProps {
    scripts: GeneratedScript[];
    factCheckCount: number;
    ideasGeneratedCount: number;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#AF19FF', '#FF4560', '#775DD0'];

const InfoCard: React.FC<{ title: string; value: string | number; icon: string }> = ({ title, value, icon }) => (
  <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md flex items-center space-x-4 space-x-reverse">
    <div className="text-4xl">{icon}</div>
    <div>
      <p className="text-gray-500 dark:text-gray-400 text-sm">{title}</p>
      <p className="text-2xl font-bold text-gray-800 dark:text-white">{value}</p>
    </div>
  </div>
);

const getHostname = (url: string) => {
    try {
        return new URL(url).hostname.replace('www.', '');
    } catch (e) {
        return 'مصدر غير صالح';
    }
}

export const Dashboard: React.FC<DashboardProps> = ({ scripts, factCheckCount, ideasGeneratedCount }) => {
    
    const scriptsPerProgramData = React.useMemo(() => {
        if (!scripts || scripts.length === 0) return [];
        const counts = scripts.reduce((acc, script) => {
            acc[script.programName] = (acc[script.programName] || 0) + 1;
            return acc;
        }, {} as Record<string, number>);
        return Object.entries(counts).map(([name, count]) => ({ name, count }));
    }, [scripts]);

    const sourceUsageData = React.useMemo(() => {
        if (!scripts || scripts.length === 0) return [];
        const allSources = scripts.flatMap(script => script.sources);
        // FIX: Explicitly typing the accumulator to fix type inference issues with reduce.
        const counts = allSources.reduce((acc: Record<string, number>, source) => {
            const domain = getHostname(source.uri);
            if (domain !== 'مصدر غير صالح') {
                acc[domain] = (acc[domain] || 0) + 1;
            }
            return acc;
        }, {} as Record<string, number>);
        
        return Object.entries(counts)
            // FIX: Explicitly cast `value` to number to resolve TypeScript inference issue in the sort function.
            .map(([name, value]) => ({ name, value: value as number }))
            .sort((a, b) => b.value - a.value)
            .slice(0, 7); // Show top 7 sources

    }, [scripts]);

    const programsUsedCount = React.useMemo(() => {
        const uniquePrograms = new Set(scripts.map(s => s.programName));
        return uniquePrograms.size;
    }, [scripts]);

    return (
        <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <InfoCard title="إجمالي النصوص" value={scripts.length} icon="📜" />
                <InfoCard title="عمليات تدقيق الحقائق" value={factCheckCount} icon="✔️" />
                <InfoCard title="الأفكار المولدة" value={ideasGeneratedCount} icon="💡" />
                <InfoCard title="البرامج المستخدمة" value={programsUsedCount} icon="🎬" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md min-h-[350px]">
                    <h3 className="text-xl font-bold mb-4">النصوص المُنشأة لكل برنامج</h3>
                    {scriptsPerProgramData.length > 0 ? (
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={scriptsPerProgramData} layout="vertical" margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke="rgba(128, 128, 128, 0.2)" />
                                <XAxis type="number" allowDecimals={false} />
                                <YAxis dataKey="name" type="category" width={110} tick={{ fontSize: 12 }} />
                                <Tooltip
                                    contentStyle={{ 
                                        backgroundColor: 'rgba(30, 41, 59, 0.9)', 
                                        borderColor: 'rgba(128, 128, 128, 0.5)',
                                        direction: 'rtl'
                                    }}
                                />
                                <Legend />
                                <Bar dataKey="count" name="عدد النصوص" fill="#3B82F6" />
                            </BarChart>
                        </ResponsiveContainer>
                    ) : (
                         <div className="flex items-center justify-center h-full text-gray-500 dark:text-gray-400">
                             <p>لا توجد بيانات لعرضها بعد.</p>
                         </div>
                    )}
                </div>

                <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md min-h-[350px]">
                    <h3 className="text-xl font-bold mb-4">المصادر الأكثر استخدامًا</h3>
                    {sourceUsageData.length > 0 ? (
                        <ResponsiveContainer width="100%" height={300}>
                            <PieChart>
                                <Pie
                                    data={sourceUsageData}
                                    cx="50%"
                                    cy="50%"
                                    labelLine={false}
                                    outerRadius={100}
                                    fill="#8884d8"
                                    dataKey="value"
                                    nameKey="name"
                                >
                                    {sourceUsageData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip
                                    contentStyle={{ 
                                        backgroundColor: 'rgba(30, 41, 59, 0.9)', 
                                        borderColor: 'rgba(128, 128, 128, 0.5)',
                                        direction: 'rtl'
                                    }}
                                />
                                <Legend />
                            </PieChart>
                        </ResponsiveContainer>
                    ) : (
                         <div className="flex items-center justify-center h-full text-gray-500 dark:text-gray-400">
                             <p>لا توجد بيانات لعرضها بعد.</p>
                         </div>
                    )}
                </div>
            </div>
        </div>
    );
};