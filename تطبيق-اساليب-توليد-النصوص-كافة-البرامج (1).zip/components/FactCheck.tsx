import React, { useState } from 'react';
import { checkFacts } from '../services/geminiService';
import type { ApiKeys } from '../types';
import { Model, Mode } from '../types';
import { renderWithLinks } from './utils';

interface FactCheckProps {
    apiKeys: ApiKeys;
    onFactCheck: () => void;
}

export const FactCheck: React.FC<FactCheckProps> = ({ apiKeys, onFactCheck }) => {
    const [textToCheck, setTextToCheck] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [report, setReport] = useState<string>('');
    const [error, setError] = useState<string>('');
    const [selectedModel, setSelectedModel] = useState<Model>(Model.GEMINI);
    const [selectedMode, setSelectedMode] = useState<Mode>(Mode.SINGLE);

    const modelOptions: { value: Model, label: string, disabled: boolean }[] = [
      { value: Model.GEMINI, label: Model.GEMINI, disabled: false },
      { value: Model.CLAUDE, label: Model.CLAUDE, disabled: !apiKeys.claude },
      { value: Model.CHATGPT, label: Model.CHATGPT, disabled: !apiKeys.chatgpt },
      { value: Model.OTHER, label: Model.OTHER, disabled: !apiKeys.other },
    ];

    const handleCheck = async () => {
        if (!textToCheck.trim()) {
            setError('يرجى إدخال نص لتدقيقه.');
            return;
        }
        setError('');
        setIsLoading(true);
        setReport('');

        try {
            const result = await checkFacts(textToCheck, selectedMode, selectedModel, apiKeys);
            setReport(result);
            onFactCheck(); // Notify parent component for analytics
        } catch (err: any) {
            setError(err.message || 'حدث خطأ غير متوقع.');
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
                 <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md space-y-4">
                    <div>
                        <h3 className="text-xl font-bold mb-2">تدقيق الحقائق</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                            ألصق النص هنا للتحقق من دقة المعلومات. سيقوم النموذج بتحليل النص وتقديم تقرير مفصل مع روابط للمصادر.
                        </p>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="model-factcheck" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اختر نموذج التدقيق</label>
                            <select 
                                id="model-factcheck" 
                                value={selectedModel} 
                                onChange={e => setSelectedModel(e.target.value as Model)} 
                                className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500"
                            >
                              {modelOptions.map(opt => <option key={opt.value} value={opt.value} disabled={opt.disabled}>{opt.label}{opt.disabled ? ' (مفتاح غير مضاف)' : ''}</option>)}
                            </select>
                        </div>
                         <div>
                            <label htmlFor="mode-factcheck" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اختر وضع التدقيق</label>
                            <select 
                                id="mode-factcheck" 
                                value={selectedMode} 
                                onChange={e => setSelectedMode(e.target.value as Mode)} 
                                className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500"
                            >
                              <option value={Mode.SINGLE}>{Mode.SINGLE}</option>
                              <option value={Mode.HYBRID}>{Mode.HYBRID}</option>
                              <option value={Mode.CROSS_CHECK}>{Mode.CROSS_CHECK}</option>
                            </select>
                        </div>
                    </div>
                     <p className="text-xs text-gray-500 dark:text-gray-400 -mt-2">الأوضاع المتقدمة تستخدم Gemini بالتنسيق مع النموذج المختار لنتائج أفضل.</p>
                    <textarea 
                        value={textToCheck}
                        onChange={e => setTextToCheck(e.target.value)}
                        placeholder="أدخل النص هنا..."
                        className="w-full h-64 p-3 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500"
                    />
                     <button onClick={handleCheck} disabled={isLoading} className="w-full flex justify-center items-center py-2 px-6 border border-transparent rounded-md shadow-sm text-md font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed">
                         {isLoading ? 'جاري التدقيق...' : '✔️ تدقيق النص'}
                    </button>
                    {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
                 </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
                <h3 className="text-2xl font-bold mb-4">تقرير التدقيق</h3>
                {isLoading && <p className="text-gray-500 animate-pulse">جاري تحليل النص والتحقق من الحقائق عبر عدة نماذج...</p>}
                {!isLoading && !report && (
                    <div className="text-center py-10 text-gray-500 dark:text-gray-400">
                        <p>سيظهر تقرير تدقيق الحقائق هنا.</p>
                    </div>
                )}
                {report && (
                    <div className="prose prose-sm sm:prose dark:prose-invert max-w-none whitespace-pre-wrap leading-relaxed">
                        {renderWithLinks(report)}
                    </div>
                )}
            </div>
        </div>
    );
};
