import React, { useState } from 'react';
import type { Program } from '../types';
import { VIEW } from '../types';
import { AddProgramModal } from './AddProgramModal';

interface ProgramCardProps {
    program: Program;
    onViewDetails: () => void;
    onEdit: () => void;
}

const ProgramCard: React.FC<ProgramCardProps> = ({program, onViewDetails, onEdit}) => (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 group relative">
        <div className="absolute top-3 left-3">
             <button 
                onClick={(e) => {
                    e.stopPropagation(); // Prevent card click
                    onEdit();
                }}
                className="p-2 rounded-full text-gray-400 bg-gray-100 dark:bg-gray-900/50 hover:bg-blue-100 dark:hover:bg-blue-900/50 hover:text-blue-600 dark:hover:text-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                aria-label={`تعديل برنامج ${program.name}`}
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
                    <path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" />
                </svg>
            </button>
        </div>
        <div onClick={onViewDetails} className="cursor-pointer text-right">
            <h3 className="text-xl font-bold text-blue-500 dark:text-blue-400 mb-2">{program.name}</h3>
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">{program.genre}</p>
            <div className="text-xs space-y-2 text-gray-500 dark:text-gray-400">
                <p><span className="font-semibold">الجمهور:</span> {program.targetAudience}</p>
                <p><span className="font-semibold">مدة الحلقة:</span> {program.episodeLength}</p>
            </div>
        </div>
    </div>
);

interface ProgramManagementProps {
    programs: Program[];
    setView: (view: VIEW) => void;
    setSelectedProgram: (program: Program) => void;
    addProgram: (programData: Omit<Program, 'id'>) => void;
    updateProgram: (program: Program) => void;
}

export const ProgramManagement: React.FC<ProgramManagementProps> = ({ programs, setView, setSelectedProgram, addProgram, updateProgram }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [programToEdit, setProgramToEdit] = useState<Program | null>(null);
  
  const handleProgramClick = (program: Program) => {
      setSelectedProgram(program);
      setView(VIEW.PROGRAM_DETAILS);
  }

  const handleOpenEditModal = (program: Program) => {
    setProgramToEdit(program);
    setIsModalOpen(true);
  };
  
  const handleSaveProgram = (programData: Omit<Program, 'id'> | Program) => {
    if ('id' in programData) {
        updateProgram(programData as Program);
    } else {
        addProgram(programData);
    }
    setIsModalOpen(false);
    setProgramToEdit(null);
  };
  
  return (
    <div>
        <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">البرامج المتاحة</h2>
            <button 
                onClick={() => { setProgramToEdit(null); setIsModalOpen(true); }}
                className="flex items-center space-x-2 space-x-reverse bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors shadow"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
                </svg>
                <span>إضافة برنامج جديد</span>
            </button>
        </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {programs.map(program => (
          <ProgramCard 
            key={program.id} 
            program={program} 
            onViewDetails={() => handleProgramClick(program)} 
            onEdit={() => handleOpenEditModal(program)}
          />
        ))}
      </div>
      <AddProgramModal 
        isOpen={isModalOpen}
        onClose={() => { setIsModalOpen(false); setProgramToEdit(null); }}
        onSave={handleSaveProgram}
        programToEdit={programToEdit}
      />
    </div>
  );
};