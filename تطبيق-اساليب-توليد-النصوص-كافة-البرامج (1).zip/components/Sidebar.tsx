
import React from 'react';
import { VIEW } from '../types';

interface SidebarProps {
  currentView: VIEW;
  setView: (view: VIEW) => void;
}

const iconMap: Record<VIEW, string> = {
  [VIEW.DASHBOARD]: '📊',
  [VIEW.PROGRAM_MANAGEMENT]: '🎬',
  [VIEW.SCRIPT_LIBRARY]: '📚',
  [VIEW.NEW_SCRIPT]: '📝',
  [VIEW.EPISODE_IDEAS]: '💡',
  [VIEW.DEEP_RESEARCH]: '🌍',
  [VIEW.FACT_CHECK]: '✔️',
  [VIEW.SETTINGS]: '🔑',
  [VIEW.PROGRAM_DETAILS]: '🎬', // Use the same icon as management
};

export const Sidebar: React.FC<SidebarProps> = ({ currentView, setView }) => {
  // Exclude PROGRAM_DETAILS from the menu items
  const menuItems = Object.values(VIEW).filter(v => v !== VIEW.PROGRAM_DETAILS);

  return (
    <aside className="w-64 bg-gray-50 dark:bg-gray-800/50 border-l border-gray-200 dark:border-gray-700/50 h-screen sticky top-0 flex flex-col">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700/50 flex items-center space-x-3 space-x-reverse">
        <span className="text-3xl">📺</span>
        <h1 className="text-xl font-bold text-gray-800 dark:text-white">Discovery AI</h1>
      </div>
      <nav className="flex-1 p-4 space-y-2">
        <p className="text-sm font-semibold text-gray-500 dark:text-gray-400 px-2 uppercase">القائمة الرئيسية</p>
        {menuItems.map((item) => {
           const isActive = currentView === item || (currentView === VIEW.PROGRAM_DETAILS && item === VIEW.PROGRAM_MANAGEMENT);
           return (
            <a
              key={item}
              href="#"
              onClick={(e) => {
                e.preventDefault();
                setView(item);
              }}
              className={`flex items-center space-x-3 space-x-reverse px-4 py-2.5 text-sm font-medium rounded-lg transition-colors duration-200 ${
                isActive
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              {/* Fix: Add type assertion to resolve indexing error. */}
              <span className="text-lg">{iconMap[item as VIEW]}</span>
              <span>{item}</span>
            </a>
           );
        })}
      </nav>
      <div className="p-4 border-t border-gray-200 dark:border-gray-700/50 text-center text-xs text-gray-500">
        <p>الإصدار 1.0.0</p>
        <p>&copy; 2024 - تم إنشاؤه بواسطة AI</p>
      </div>
    </aside>
  );
};
