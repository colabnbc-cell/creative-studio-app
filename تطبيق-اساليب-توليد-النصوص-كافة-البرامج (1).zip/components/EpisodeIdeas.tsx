import React, { useState } from 'react';
import { generateIdeas } from '../services/geminiService';
import type { Program, ApiKeys } from '../types';
import { Mode, Model } from '../types';
import { renderWithLinks } from './utils';

interface EpisodeIdeasProps {
    programs: Program[];
    onIdeasGenerated: () => void;
    apiKeys: ApiKeys;
}

export const EpisodeIdeas: React.FC<EpisodeIdeasProps> = ({ programs, onIdeasGenerated, apiKeys }) => {
    const [selectedProgramId, setSelectedProgramId] = useState<string>(programs[0]?.id || '');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [ideas, setIdeas] = useState<string>('');
    const [error, setError] = useState<string>('');
    const [selectedMode, setSelectedMode] = useState<Mode>(Mode.SINGLE);
    const [selectedModel, setSelectedModel] = useState<Model>(Model.GEMINI);

    const handleGenerate = async () => {
        setError('');
        setIsLoading(true);
        setIdeas('');

        try {
            const selectedProgram = programs.find(p => p.id === selectedProgramId);
            if (!selectedProgram) {
                throw new Error('لم يتم العثور على البرنامج المحدد.');
            }
            
            const result = await generateIdeas(selectedProgram, selectedMode, selectedModel, apiKeys);
            
            setIdeas(result);
            onIdeasGenerated(); // Notify parent component for analytics
        } catch (err: any) {
            setError(err.message || 'حدث خطأ غير متوقع.');
        } finally {
            setIsLoading(false);
        }
    };

     const modelOptions: { value: Model, label: string, disabled: boolean }[] = [
      { value: Model.GEMINI, label: Model.GEMINI, disabled: false },
      { value: Model.CLAUDE, label: Model.CLAUDE, disabled: !apiKeys.claude },
      { value: Model.CHATGPT, label: Model.CHATGPT, disabled: !apiKeys.chatgpt },
      { value: Model.OTHER, label: Model.OTHER, disabled: !apiKeys.other },
    ];
    
    return (
        <div className="max-w-4xl mx-auto">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md mb-6">
                <h3 className="text-xl font-bold mb-4">مولّد أفكار الحلقات</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
                    <div className="sm:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label htmlFor="program-ideas" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اختر البرنامج</label>
                            <select id="program-ideas" value={selectedProgramId} onChange={e => setSelectedProgramId(e.target.value)} className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500">
                                {programs.map(program => <option key={program.id} value={program.id}>{program.name}</option>)}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="model-ideas" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اختر النموذج</label>
                            <select id="model-ideas" value={selectedModel} onChange={e => setSelectedModel(e.target.value as Model)} className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500">
                                {modelOptions.map(opt => <option key={opt.value} value={opt.value} disabled={opt.disabled}>{opt.label}{opt.disabled ? ' (مفتاح غير مضاف)' : ''}</option>)}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="mode-ideas" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اختر الوضع</label>
                            <select id="mode-ideas" value={selectedMode} onChange={e => setSelectedMode(e.target.value as Mode)} className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500">
                                {Object.values(Mode).map(mode => <option key={mode} value={mode}>{mode}</option>)}
                            </select>
                        </div>
                    </div>
                    <button onClick={handleGenerate} disabled={isLoading} className="w-full flex justify-center items-center py-2 px-6 border border-transparent rounded-md shadow-sm text-md font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed whitespace-nowrap">
                         {isLoading ? 'جاري التوليد...' : '💡 توليد أفكار'}
                    </button>
                </div>
                 <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">الأوضاع المتقدمة تستخدم النماذج المختلفة بشكل حقيقي للحصول على أفضل النتائج.</p>
                {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 min-h-[300px]">
                <h3 className="text-2xl font-bold mb-4">الأفكار المقترحة</h3>
                {isLoading && <p className="text-gray-500 animate-pulse">جاري تحليل المواضيع المرجعية والبحث عن أفكار مشابهة وموثقة...</p>}
                {!isLoading && !ideas && (
                    <div className="text-center py-10 text-gray-500 dark:text-gray-400">
                        <p>ستظهر الأفكار الجديدة المدعومة بالمصادر هنا.</p>
                    </div>
                )}
                {ideas && (
                    <div className="prose prose-sm sm:prose dark:prose-invert max-w-none whitespace-pre-wrap leading-relaxed">
                        {renderWithLinks(ideas)}
                    </div>
                )}
            </div>
        </div>
    );
};
