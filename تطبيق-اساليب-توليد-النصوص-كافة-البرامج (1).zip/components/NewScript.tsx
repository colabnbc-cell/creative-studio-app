import React, { useState, useRef } from 'react';
import { generateScript, chatToModifyScript } from '../services/geminiService';
import type { ApiKeys, Program, GeneratedScript, Source, Message as ChatMessage } from '../types';
import { Model, Mode } from '../types';
import { renderWithLinks } from './utils';
import { ChatInterface } from './ChatInterface';

interface NewScriptProps {
    apiKeys: ApiKeys;
    addScriptToLibrary: (script: GeneratedScript) => void;
    programs: Program[];
}

export const NewScript: React.FC<NewScriptProps> = ({ apiKeys, addScriptToLibrary, programs }) => {
    const [selectedProgramId, setSelectedProgramId] = useState<string>(programs[0]?.id || '');
    const [topic, setTopic] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string>('');
    const [selectedModel, setSelectedModel] = useState<Model>(Model.GEMINI);
    const [selectedMode, setSelectedMode] = useState<Mode>(Mode.SINGLE);
    
    const [generatedContent, setGeneratedContent] = useState<string>('');
    const [sources, setSources] = useState<Source[]>([]);
    const [scriptTitle, setScriptTitle] = useState('');
    
    // State for chat modification
    const [isModifying, setIsModifying] = useState(false);
    const originalTopicRef = useRef('');


    const handleGenerate = async () => {
        const selectedProgram = programs.find(p => p.id === selectedProgramId);
        if (!topic.trim() || !selectedProgram) {
            setError('يرجى اختيار برنامج وإدخال موضوع.');
            return;
        }
        setError('');
        setIsLoading(true);
        setGeneratedContent('');
        setSources([]);
        setScriptTitle('');
        originalTopicRef.current = topic; // Save the original topic for chat context

        try {
            const { script, sources: newSources } = await generateScript(selectedProgram, topic, selectedMode, selectedModel, apiKeys);

            const titleMatch = script.match(/عنوان الحلقة: "([^"]+)"/i) || script.match(/عنوان الحلقة:\s*"([^"]+)"/i);
            const title = titleMatch ? titleMatch[1] : topic;
            const content = titleMatch ? script.substring(script.indexOf('\n') + 1).trim() : script;

            setGeneratedContent(content);
            setScriptTitle(title);
            setSources(newSources);
        } catch (err: any) {
            setError(err.message || 'حدث خطأ غير متوقع أثناء إنشاء النص.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleModifyScript = async (message: string) => {
        const selectedProgram = programs.find(p => p.id === selectedProgramId);
        if (!message || !selectedProgram || !generatedContent) return;

        setIsModifying(true);
        setError('');
        
        try {
            const { script, sources: newSources } = await chatToModifyScript(
                selectedProgram,
                originalTopicRef.current,
                generatedContent,
                message,
                selectedModel,
                apiKeys
            );
            
            const titleMatch = script.match(/عنوان الحلقة: "([^"]+)"/i) || script.match(/عنوان الحلقة:\s*"([^"]+)"/i);
            const title = titleMatch ? titleMatch[1] : scriptTitle; // Keep old title if new one isn't found
            const content = titleMatch ? script.substring(script.indexOf('\n') + 1).trim() : script;

            setGeneratedContent(content);
            setScriptTitle(title);
            setSources(newSources);

        } catch (err: any) {
             setError(err.message || 'حدث خطأ أثناء تعديل النص.');
             console.error(err);
        } finally {
            setIsModifying(false);
        }
    };


    const handleSave = () => {
        const selectedProgram = programs.find(p => p.id === selectedProgramId);
        if (generatedContent && selectedProgram) {
            const newScript: GeneratedScript = {
                title: scriptTitle,
                content: generatedContent,
                programName: selectedProgram.name,
                date: new Date().toLocaleDateString('ar-EG'),
                sources: sources,
            };
            addScriptToLibrary(newScript);
            // Optionally clear the form
            setTopic('');
            setGeneratedContent('');
            setSources([]);
            setScriptTitle('');
        }
    };

    const modelOptions = [
      { value: Model.GEMINI, label: Model.GEMINI, disabled: false },
      { value: Model.CLAUDE, label: Model.CLAUDE, disabled: !apiKeys.claude },
      { value: Model.CHATGPT, label: Model.CHATGPT, disabled: !apiKeys.chatgpt },
      { value: Model.OTHER, label: Model.OTHER, disabled: !apiKeys.other },
    ];

    return (
        <div className="max-w-4xl mx-auto">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md mb-6">
                <h3 className="text-xl font-bold mb-4">إنشاء نص جديد</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label htmlFor="program" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اختر البرنامج</label>
                        <select id="program" value={selectedProgramId} onChange={e => setSelectedProgramId(e.target.value)} className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500">
                             {programs.map(program => <option key={program.id} value={program.id}>{program.name}</option>)}
                        </select>
                    </div>
                     <div>
                        <label htmlFor="model" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اختر النموذج</label>
                        <select id="model" value={selectedModel} onChange={e => setSelectedModel(e.target.value as Model)} className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500">
                           {modelOptions.map(opt => <option key={opt.value} value={opt.value} disabled={opt.disabled}>{opt.label}{opt.disabled ? ' (مفتاح غير مضاف)' : ''}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="mode" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اختر الوضع</label>
                        <select id="mode" value={selectedMode} onChange={e => setSelectedMode(e.target.value as Mode)} className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500">
                           {Object.values(Mode).map(mode => <option key={mode} value={mode}>{mode}</option>)}
                        </select>
                    </div>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">الأوضاع المتقدمة تستخدم Gemini بالتنسيق مع النموذج المختار لتحسين النتائج.</p>

                 <div className="mt-4">
                    <label htmlFor="topic" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">موضوع الحلقة</label>
                    <input type="text" id="topic" value={topic} onChange={e => setTopic(e.target.value)} placeholder="مثال: أغرب الظواهر الفلكية" className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500" />
                </div>
                <div className="mt-6">
                    <button onClick={handleGenerate} disabled={isLoading || isModifying} className="w-full flex justify-center items-center py-2.5 px-6 border border-transparent rounded-md shadow-sm text-md font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed">
                        {isLoading ? 'جاري الإنشاء...' : '📝 إنشاء النص'}
                    </button>
                </div>
                {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 min-h-[300px]">
                 {(isLoading || isModifying) && <p className="text-gray-500 animate-pulse">{isLoading ? 'جاري كتابة النص والبحث عن المصادر...' : 'جاري تطبيق التعديلات...'}</p>}
                 {!isLoading && !generatedContent && (
                    <div className="text-center py-10 text-gray-500 dark:text-gray-400">
                        <p>سيظهر النص المُنشأ هنا.</p>
                    </div>
                )}
                {generatedContent && (
                    <>
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-2xl font-bold">{scriptTitle}</h3>
                            <button onClick={handleSave} className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm font-medium">
                                حفظ في المكتبة
                            </button>
                        </div>
                        <div className="prose prose-sm sm:prose dark:prose-invert max-w-none whitespace-pre-wrap leading-relaxed mb-6">
                           {renderWithLinks(generatedContent)}
                        </div>
                        {sources.length > 0 && (
                            <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
                                <h4 className="text-lg font-semibold mb-2">المصادر</h4>
                                <ul className="list-disc pr-5 space-y-1">
                                    {sources.map((source, index) => (
                                        <li key={index} className="text-sm">
                                            <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">
                                                {source.title || source.uri}
                                            </a>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                        <div className="mt-8 pt-6 border-t border-dashed border-gray-300 dark:border-gray-600">
                             <ChatInterface 
                                onSendMessage={handleModifyScript}
                                isSending={isModifying}
                                title=" إجراء تعديلات فورية"
                                placeholder="اطلب تعديلاً على النص أعلاه..."
                             />
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};
