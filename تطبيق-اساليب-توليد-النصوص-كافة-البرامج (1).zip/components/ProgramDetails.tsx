import React, { useState, useRef } from 'react';
import type { Program, ApiKeys, GeneratedScript, Source } from '../types';
import { Model, Mode } from '../types';
import { generateScript, chatToModifyScript } from '../services/geminiService';
import { renderWithLinks } from './utils';
import { ChatInterface } from './ChatInterface';

interface ProgramDetailsProps {
    program: Program;
    apiKeys: ApiKeys;
    addScriptToLibrary: (script: GeneratedScript) => void;
    updateProgram: (program: Program) => void; 
}

const DetailItem: React.FC<{ label: string; value: string }> = ({ label, value }) => (
    <div>
        <p className="text-sm font-semibold text-gray-500 dark:text-gray-400">{label}</p>
        <p className="text-base text-gray-800 dark:text-gray-200">{value}</p>
    </div>
);

export const ProgramDetails: React.FC<ProgramDetailsProps> = ({ program, apiKeys, addScriptToLibrary, updateProgram }) => {
    const [topic, setTopic] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string>('');
    const [selectedModel, setSelectedModel] = useState<Model>(Model.GEMINI);
    const [selectedMode, setSelectedMode] = useState<Mode>(Mode.SINGLE);
    
    const [generatedContent, setGeneratedContent] = useState<string>('');
    const [sources, setSources] = useState<Source[]>([]);
    const [scriptTitle, setScriptTitle] = useState('');
    
    const [newReference, setNewReference] = useState('');

    // State for chat modification
    const [isModifying, setIsModifying] = useState(false);
    const originalTopicRef = useRef('');

    const handleAddReference = () => {
        if (newReference.trim()) {
            const updatedProgram = {
                ...program,
                styleReferences: [...program.styleReferences, newReference.trim()],
            };
            updateProgram(updatedProgram);
            setNewReference('');
        }
    };

    const handleDeleteReference = (indexToDelete: number) => {
        const updatedProgram = {
            ...program,
            styleReferences: program.styleReferences.filter((_, index) => index !== indexToDelete),
        };
        updateProgram(updatedProgram);
    };

    const handleGenerate = async () => {
        if (!topic.trim()) {
            setError('يرجى إدخال موضوع للحلقة.');
            return;
        }
        setError('');
        setIsLoading(true);
        setGeneratedContent('');
        setSources([]);
        setScriptTitle('');
        originalTopicRef.current = topic;

        try {
            const { script, sources: newSources } = await generateScript(program, topic, selectedMode, selectedModel, apiKeys);
            const titleMatch = script.match(/عنوان الحلقة: "([^"]+)"/i) || script.match(/عنوان الحلقة:\s*"([^"]+)"/i);
            const title = titleMatch ? titleMatch[1] : topic;
            const content = titleMatch ? script.substring(script.indexOf('\n') + 1).trim() : script;

            setGeneratedContent(content);
            setScriptTitle(title);
            setSources(newSources);
        } catch (err: any) {
            setError(err.message || 'حدث خطأ غير متوقع.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleSave = () => {
        if (generatedContent) {
            const newScript: GeneratedScript = {
                title: scriptTitle,
                content: generatedContent,
                programName: program.name,
                date: new Date().toLocaleDateString('ar-EG'),
                sources: sources,
            };
            addScriptToLibrary(newScript);
            setTopic('');
            setGeneratedContent('');
            setSources([]);
            setScriptTitle('');
        }
    };

    const handleModifyScript = async (message: string) => {
        if (!message || !generatedContent) return;

        setIsModifying(true);
        setError('');
        
        try {
            const { script, sources: newSources } = await chatToModifyScript(
                program,
                originalTopicRef.current,
                generatedContent,
                message,
                selectedModel,
                apiKeys
            );
            
            const titleMatch = script.match(/عنوان الحلقة: "([^"]+)"/i) || script.match(/عنوان الحلقة:\s*"([^"]+)"/i);
            const title = titleMatch ? titleMatch[1] : scriptTitle;
            const content = titleMatch ? script.substring(script.indexOf('\n') + 1).trim() : script;

            setGeneratedContent(content);
            setScriptTitle(title);
            setSources(newSources);

        } catch (err: any) {
             setError(err.message || 'حدث خطأ أثناء تعديل النص.');
        } finally {
            setIsModifying(false);
        }
    };

    
    const modelOptions = [
      { value: Model.GEMINI, label: Model.GEMINI, disabled: false },
      { value: Model.CLAUDE, label: Model.CLAUDE, disabled: !apiKeys.claude },
      { value: Model.CHATGPT, label: Model.CHATGPT, disabled: !apiKeys.chatgpt },
      { value: Model.OTHER, label: Model.OTHER, disabled: !apiKeys.other },
    ];

    return (
        <div className="space-y-8">
            {/* Program Details Section */}
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md">
                <h3 className="text-xl font-bold mb-4">تفاصيل البرنامج</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <DetailItem label="النوع" value={program.genre} />
                    <DetailItem label="الجمهور المستهدف" value={program.targetAudience} />
                    <DetailItem label="مدة الحلقة" value={program.episodeLength} />
                </div>
                 <h4 className="text-lg font-semibold mb-3">النصوص المرجعية للأسلوب ({program.styleReferences.length})</h4>
                 <div className="space-y-2 max-h-48 overflow-y-auto pr-4 border-r-2 border-gray-200 dark:border-gray-700">
                     {program.styleReferences.map((ref, index) => (
                         <div key={index} className="flex justify-between items-start group">
                            <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex-1">
                                {ref}
                            </p>
                             <button onClick={() => handleDeleteReference(index)} className="mr-2 text-red-500 hover:text-red-700 opacity-0 group-hover:opacity-100 transition-opacity" aria-label="حذف المرجع">
                                 &times;
                             </button>
                         </div>
                     ))}
                     {program.styleReferences.length === 0 && <p className="text-sm text-gray-500">لا توجد نصوص مرجعية. أضف نصًا لتعليم النموذج أسلوب البرنامج.</p>}
                 </div>
                 <div className="mt-4 flex space-x-2 space-x-reverse">
                     <input
                         type="text"
                         value={newReference}
                         onChange={(e) => setNewReference(e.target.value)}
                         placeholder="أضف نصًا مرجعيًا جديدًا هنا..."
                         className="flex-1 p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500 text-sm"
                     />
                     <button onClick={handleAddReference} className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm">إضافة</button>
                 </div>
            </div>

            {/* Script Generation Section */}
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md">
                 <h3 className="text-xl font-bold mb-4">إنشاء حلقة جديدة لـ "{program.name}"</h3>
                 <div className="space-y-4">
                    <div>
                        <label htmlFor="topic-details" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">موضوع الحلقة</label>
                        <input type="text" id="topic-details" value={topic} onChange={e => setTopic(e.target.value)} placeholder="مثال: سر المثلثات الغامضة في الطبيعة" className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500" />
                    </div>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="model-details" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اختر النموذج</label>
                            <select id="model-details" value={selectedModel} onChange={e => setSelectedModel(e.target.value as Model)} className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500">
                               {modelOptions.map(opt => <option key={opt.value} value={opt.value} disabled={opt.disabled}>{opt.label}{opt.disabled ? ' (مفتاح غير مضاف)' : ''}</option>)}
                            </select>
                        </div>
                         <div>
                            <label htmlFor="mode-details" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اختر الوضع</label>
                            <select id="mode-details" value={selectedMode} onChange={e => setSelectedMode(e.target.value as Mode)} className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500">
                               {Object.values(Mode).map(mode => <option key={mode} value={mode}>{mode}</option>)}
                            </select>
                        </div>
                    </div>
                    <button onClick={handleGenerate} disabled={isLoading || isModifying} className="w-full flex justify-center items-center py-2 px-6 border border-transparent rounded-md shadow-sm text-md font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed">
                        {isLoading ? 'جاري الإنشاء...' : '📝 إنشاء النص'}
                    </button>
                    {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
                 </div>
            </div>

            {/* Generated Script Display & Chat */}
             {(isLoading || generatedContent) && (
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 min-h-[300px]">
                    {isLoading && <p className="text-gray-500 animate-pulse">جاري كتابة النص...</p>}
                    
                    {generatedContent && (
                        <>
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="text-xl font-bold">{scriptTitle}</h3>
                                <button onClick={handleSave} className="bg-green-600 text-white px-3 py-1.5 rounded-lg hover:bg-green-700 transition-colors text-sm font-medium">حفظ في المكتبة</button>
                            </div>
                            <div className="prose prose-sm dark:prose-invert max-w-none whitespace-pre-wrap leading-relaxed max-h-80 overflow-y-auto mb-6">
                               {renderWithLinks(generatedContent)}
                            </div>
                            {sources.length > 0 && (
                                <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                                    <h4 className="text-base font-semibold mb-2">المصادر</h4>
                                    <ul className="list-disc pr-4 space-y-1 text-xs max-h-24 overflow-y-auto">
                                        {sources.map((source, index) => (
                                            <li key={index}>
                                                <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">{source.title || source.uri}</a>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                             <div className="mt-8 pt-6 border-t border-dashed border-gray-300 dark:border-gray-600">
                                <ChatInterface 
                                    onSendMessage={handleModifyScript}
                                    isSending={isModifying}
                                    title="إجراء تعديلات فورية"
                                    placeholder="اطلب تعديلاً على النص أعلاه..."
                                />
                            </div>
                        </>
                    )}
                </div>
             )}
            
            {/* Brainstorming Chat Interface Section */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md">
                <ChatInterface program={program} title="🤖 مساعد العصف الذهني" placeholder="اكتب رسالتك هنا للعصف الذهني..." />
            </div>
        </div>
    );
};
