import React from 'react';

// Helper to render markdown as HTML and style custom verification symbols/verdicts
export const renderWithLinks = (text: string) => {
    if (!text) return null;
    
    // First, process links
    let processedText = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" class="text-blue-500 hover:underline">$1</a>');

    const verdictStyles = {
        correct: 'font-bold text-green-600 dark:text-green-400',
        partial: 'font-bold text-yellow-600 dark:text-yellow-400',
        incorrect: 'font-bold text-red-600 dark:text-red-400',
    };
    
    // Process new, specific fact-check verdicts, consuming the markdown bolding.
    // Order is important to catch the more specific cases first.
    processedText = processedText
        .replace(/\*\*✅ صحيح\*\*/g, `<strong class="${verdictStyles.correct}">✅ صحيح</strong>`)
        .replace(/\*\*⚠️ صحيح جزئيًا \/ مختلف عليه\*\*/g, `<strong class="${verdictStyles.partial}">⚠️ صحيح جزئيًا / مختلف عليه</strong>`)
        .replace(/\*\*❌ خاطئ\*\*/g, `<strong class="${verdictStyles.incorrect}">❌ خاطئ</strong>`)
        .replace(/\*\*صحيح\*\*/g, `<strong class="${verdictStyles.correct}">صحيح</strong>`)
        .replace(/\*\*صحيح جزئيًا\*\*/g, `<strong class="${verdictStyles.partial}">صحيح جزئيًا</strong>`)
        .replace(/\*\*خاطئ\*\*/g, `<strong class="${verdictStyles.incorrect}">خاطئ</strong>`);

    // Process general verification symbols that were not part of a verdict
    processedText = processedText
        .replace(/✅/g, '<span class="text-green-500 font-bold" title="تم تأكيدها من عدة نماذج">✅</span>')
        .replace(/❌/g, '<span class="text-red-500 font-bold" title="غير صحيحة حسب عدة نماذج">❌</span>')
        .replace(/⚠️/g, '<span class="text-yellow-500 font-bold" title="يوجد اختلاف بين النماذج">⚠️</span>')
        .replace(/💡/g, '<span class="text-purple-500 font-bold" title="فكرة فريدة ومبتكرة">💡</span>');

    // Process any remaining general bold markdown
    processedText = processedText.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

    return <div dangerouslySetInnerHTML={{ __html: processedText }} />;
};