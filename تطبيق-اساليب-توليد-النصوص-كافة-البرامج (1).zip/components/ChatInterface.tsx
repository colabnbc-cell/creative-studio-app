import React, { useState, useEffect, useRef } from 'react';
import type { Program, Message } from '../types';
import { startChat, sendChatMessage } from '../services/geminiService';
import { renderWithLinks } from './utils';

interface ChatInterfaceProps {
    program?: Program;
    onSendMessage?: (message: string) => Promise<void>;
    isSending: boolean;
    title: string;
    placeholder: string;
}

// A more generic ChatInterface that can be used for both brainstorming and modification
export const ChatInterface: React.FC<Partial<ChatInterfaceProps>> = ({ 
    program, 
    onSendMessage,
    isSending: externalIsSending = false,
    title = "🤖 مساعد الدردشة",
    placeholder = "اكتب رسالتك هنا..."
}) => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState('');
    const [internalIsSending, setInternalIsSending] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const isModificationMode = !!onSendMessage;

    const isSending = isModificationMode ? externalIsSending : internalIsSending;

    // Effect for initializing brainstorming chat
    useEffect(() => {
        if (program && !isModificationMode) {
            startChat(program);
            setMessages([{
                sender: 'bot',
                text: `مرحباً! أنا مساعدك الإبداعي لبرنامج "${program.name}". كيف يمكنني المساعدة اليوم في العصف الذهني أو كتابة النصوص؟`
            }]);
        }
    }, [program, isModificationMode]);

    // Effect for scrolling
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || isSending) return;

        const userMessage: Message = { sender: 'user', text: input };
        
        // If it's a modification chat, we don't manage the message history here
        if (isModificationMode && onSendMessage) {
             onSendMessage(input);
             setInput('');
             return;
        }

        // Handle brainstorming chat history
        setMessages(prev => [...prev, userMessage, { sender: 'bot', text: '', isLoading: true }]);
        setInput('');
        setInternalIsSending(true);

        try {
            const response = await sendChatMessage(userMessage.text);
            const botMessage: Message = { sender: 'bot', text: response.text };

            setMessages(prev => {
                const newMessages = [...prev];
                newMessages[newMessages.length - 1] = botMessage;
                return newMessages;
            });

        } catch (error) {
            console.error('Chat error:', error);
            const errorMessage: Message = { sender: 'bot', text: 'عذراً، حدث خطأ أثناء التواصل مع المساعد.' };
             setMessages(prev => {
                const newMessages = [...prev];
                newMessages[newMessages.length - 1] = errorMessage;
                return newMessages;
            });
        } finally {
            setInternalIsSending(false);
        }
    };

    return (
        <div className="p-6">
            <h3 className="text-xl font-bold mb-4">{title}</h3>
            <div className={`${!isModificationMode ? 'h-96' : ''} flex flex-col`}>
                {!isModificationMode && (
                    <div className="flex-1 overflow-y-auto pr-4 space-y-4 mb-4">
                        {messages.map((msg, index) => (
                            <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`max-w-md lg:max-w-lg p-3 rounded-2xl ${msg.sender === 'user' ? 'bg-blue-500 text-white rounded-br-lg' : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-bl-lg'}`}>
                                    {msg.isLoading ? (
                                        <div className="flex items-center space-x-2 space-x-reverse">
                                            <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse"></div>
                                            <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse [animation-delay:0.2s]"></div>
                                            <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse [animation-delay:0.4s]"></div>
                                        </div>
                                    ) : (
                                        <div className="prose prose-sm dark:prose-invert max-w-none whitespace-pre-wrap leading-relaxed">
                                            {renderWithLinks(msg.text)}
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                         <div ref={messagesEndRef} />
                    </div>
                )}
                <form onSubmit={handleSendMessage} className="flex items-center space-x-2 space-x-reverse">
                    <input
                        type="text"
                        value={input}
                        onChange={e => setInput(e.target.value)}
                        placeholder={placeholder}
                        disabled={isSending}
                        className="flex-1 p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500"
                    />
                    <button type="submit" disabled={isSending || !input.trim()} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed">
                        {isSending ? 'جاري...' : 'إرسال'}
                    </button>
                </form>
            </div>
        </div>
    );
};
