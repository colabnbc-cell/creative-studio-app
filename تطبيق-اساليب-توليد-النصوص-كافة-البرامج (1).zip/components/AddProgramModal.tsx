import React, { useState, useEffect } from 'react';
import type { Program } from '../types';

interface AddProgramModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (programData: Omit<Program, 'id'> | Program) => void;
    programToEdit?: Program | null;
}

export const AddProgramModal: React.FC<AddProgramModalProps> = ({ isOpen, onClose, onSave, programToEdit }) => {
    const [name, setName] = useState('');
    const [genre, setGenre] = useState('');
    const [targetAudience, setTargetAudience] = useState('');
    const [episodeLength, setEpisodeLength] = useState('نص من 130 إلى 200 كلمة');
    const [styleReferencesText, setStyleReferencesText] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        if (isOpen) {
            if (programToEdit) {
                // Populate form for editing
                setName(programToEdit.name);
                setGenre(programToEdit.genre);
                setTargetAudience(programToEdit.targetAudience);
                setEpisodeLength(programToEdit.episodeLength);
                setStyleReferencesText(programToEdit.styleReferences.join('\n'));
                setError('');
            } else {
                // Reset form for adding new
                setName('');
                setGenre('');
                setTargetAudience('');
                setEpisodeLength('نص من 130 إلى 200 كلمة');
                setStyleReferencesText('');
                setError('');
            }
        }
    }, [isOpen, programToEdit]);


    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name.trim() || !genre.trim() || !targetAudience.trim()) {
            setError('يرجى ملء جميع الحقول المطلوبة (الاسم، النوع، الجمهور).');
            return;
        }
        
        const commonData = {
            name,
            genre,
            targetAudience,
            episodeLength,
            styleReferences: styleReferencesText.split('\n').map(s => s.trim()).filter(Boolean)
        };

        if (programToEdit) {
            onSave({ ...commonData, id: programToEdit.id });
        } else {
            onSave(commonData);
        }
        
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 transition-opacity duration-300" 
            onClick={onClose}
            aria-modal="true"
            role="dialog"
        >
            <div 
                className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl p-6 md:p-8 w-11/12 md:w-2/3 lg:w-1/2 max-w-2xl transform transition-all duration-300 scale-95 opacity-0 animate-fade-in-scale" 
                onClick={e => e.stopPropagation()}
            >
                <form onSubmit={handleSubmit}>
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-2xl font-bold">{programToEdit ? 'تعديل البرنامج' : 'إضافة برنامج جديد'}</h2>
                        <button type="button" onClick={onClose} className="text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-white text-3xl font-bold">&times;</button>
                    </div>

                    {error && <p className="text-red-500 text-sm mb-4 bg-red-100 dark:bg-red-900/30 p-3 rounded-md">{error}</p>}
                    
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اسم البرنامج</label>
                            <input type="text" id="name" value={name} onChange={e => setName(e.target.value)} required className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500" />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="genre" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">النوع</label>
                                <input type="text" id="genre" value={genre} onChange={e => setGenre(e.target.value)} required className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500" />
                            </div>
                            <div>
                                <label htmlFor="targetAudience" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">الجمهور المستهدف</label>
                                <input type="text" id="targetAudience" value={targetAudience} onChange={e => setTargetAudience(e.target.value)} required className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500" />
                            </div>
                        </div>
                         <div>
                            <label htmlFor="episodeLength" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">مدة الحلقة</label>
                            <input type="text" id="episodeLength" value={episodeLength} onChange={e => setEpisodeLength(e.target.value)} className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500" />
                        </div>
                        <div>
                            <label htmlFor="styleReferences" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">نصوص مرجعية للأسلوب</label>
                            <textarea id="styleReferences" value={styleReferencesText} onChange={e => setStyleReferencesText(e.target.value)} rows={4} className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:ring-blue-500 focus:border-blue-500" placeholder="ألصق النصوص هنا، كل نص في سطر منفصل..."></textarea>
                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">سيتم اعتبار كل سطر كمرجع منفصل.</p>
                        </div>
                    </div>
                    
                    <div className="flex justify-end space-x-3 space-x-reverse mt-6">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md shadow-sm hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-600">إلغاء</button>
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700">{programToEdit ? 'حفظ التعديلات' : 'إضافة البرنامج'}</button>
                    </div>
                </form>
            </div>
             <style>{`
                @keyframes fadeInScale {
                    from { transform: scale(.95); opacity: 0; }
                    to { transform: scale(1); opacity: 1; }
                }
                .animate-fade-in-scale { animation: fadeInScale 0.2s ease-out forwards; }
            `}</style>
        </div>
    );
};